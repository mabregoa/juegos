﻿namespace Juegos
{
    partial class Matematika
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelQuestion = new System.Windows.Forms.Label();
            this.btnOpcion1 = new System.Windows.Forms.Button();
            this.btnOpcion2 = new System.Windows.Forms.Button();
            this.btnOpcion3 = new System.Windows.Forms.Button();
            this.labelResult = new System.Windows.Forms.Label();
            this.lblAciertos = new System.Windows.Forms.Label();
            this.lblTiempo = new System.Windows.Forms.Label();
            this.btnIniciar = new System.Windows.Forms.Button();
            this.btnGehiketa = new System.Windows.Forms.Button();
            this.btnKenketa = new System.Windows.Forms.Button();
            this.btnMostrarRanking = new System.Windows.Forms.Button();
            this.btnGuardarPuntuacion = new System.Windows.Forms.Button();
            this.cronometro = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // labelQuestion
            // 
            this.labelQuestion.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.labelQuestion.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelQuestion.Location = new System.Drawing.Point(100, 50);
            this.labelQuestion.Name = "labelQuestion";
            this.labelQuestion.Size = new System.Drawing.Size(824, 60);
            this.labelQuestion.TabIndex = 0;
            this.labelQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnOpcion1
            // 
            this.btnOpcion1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnOpcion1.FlatAppearance.BorderSize = 0;
            this.btnOpcion1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpcion1.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold);
            this.btnOpcion1.Location = new System.Drawing.Point(100, 370);
            this.btnOpcion1.Name = "btnOpcion1";
            this.btnOpcion1.Size = new System.Drawing.Size(250, 70);
            this.btnOpcion1.TabIndex = 1;
            this.btnOpcion1.UseVisualStyleBackColor = false;
            this.btnOpcion1.Click += new System.EventHandler(this.btnOpcion1_Click);
            // 
            // btnOpcion2
            // 
            this.btnOpcion2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnOpcion2.FlatAppearance.BorderSize = 0;
            this.btnOpcion2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpcion2.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold);
            this.btnOpcion2.Location = new System.Drawing.Point(100, 260);
            this.btnOpcion2.Name = "btnOpcion2";
            this.btnOpcion2.Size = new System.Drawing.Size(250, 70);
            this.btnOpcion2.TabIndex = 2;
            this.btnOpcion2.UseVisualStyleBackColor = false;
            this.btnOpcion2.Click += new System.EventHandler(this.btnOpcion2_Click);
            // 
            // btnOpcion3
            // 
            this.btnOpcion3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnOpcion3.FlatAppearance.BorderSize = 0;
            this.btnOpcion3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpcion3.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold);
            this.btnOpcion3.Location = new System.Drawing.Point(100, 135);
            this.btnOpcion3.Name = "btnOpcion3";
            this.btnOpcion3.Size = new System.Drawing.Size(250, 70);
            this.btnOpcion3.TabIndex = 3;
            this.btnOpcion3.UseVisualStyleBackColor = false;
            this.btnOpcion3.Click += new System.EventHandler(this.btnOpcion3_Click);
            // 
            // labelResult
            // 
            this.labelResult.ForeColor = System.Drawing.Color.DarkGreen;
            this.labelResult.Location = new System.Drawing.Point(400, 170);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(500, 50);
            this.labelResult.TabIndex = 4;
            this.labelResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAciertos
            // 
            this.lblAciertos.ForeColor = System.Drawing.Color.DarkRed;
            this.lblAciertos.Location = new System.Drawing.Point(400, 230);
            this.lblAciertos.Name = "lblAciertos";
            this.lblAciertos.Size = new System.Drawing.Size(500, 40);
            this.lblAciertos.TabIndex = 5;
            // 
            // lblTiempo
            // 
            this.lblTiempo.ForeColor = System.Drawing.Color.Indigo;
            this.lblTiempo.Location = new System.Drawing.Point(400, 280);
            this.lblTiempo.Name = "lblTiempo";
            this.lblTiempo.Size = new System.Drawing.Size(500, 40);
            this.lblTiempo.TabIndex = 6;
            // 
            // btnIniciar
            // 
            this.btnIniciar.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnIniciar.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnIniciar.ForeColor = System.Drawing.Color.White;
            this.btnIniciar.Location = new System.Drawing.Point(400, 350);
            this.btnIniciar.Name = "btnIniciar";
            this.btnIniciar.Size = new System.Drawing.Size(200, 60);
            this.btnIniciar.TabIndex = 7;
            this.btnIniciar.Text = "Hasiera";
            this.btnIniciar.UseVisualStyleBackColor = false;
            this.btnIniciar.Click += new System.EventHandler(this.btnIniciar_Click);
            // 
            // btnGehiketa
            // 
            this.btnGehiketa.BackColor = System.Drawing.Color.Orange;
            this.btnGehiketa.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnGehiketa.ForeColor = System.Drawing.Color.White;
            this.btnGehiketa.Location = new System.Drawing.Point(620, 350);
            this.btnGehiketa.Name = "btnGehiketa";
            this.btnGehiketa.Size = new System.Drawing.Size(180, 60);
            this.btnGehiketa.TabIndex = 8;
            this.btnGehiketa.Text = "+ GEHIKETA";
            this.btnGehiketa.UseVisualStyleBackColor = false;
            this.btnGehiketa.Click += new System.EventHandler(this.btnGehiketa_Click);
            // 
            // btnKenketa
            // 
            this.btnKenketa.BackColor = System.Drawing.Color.Orange;
            this.btnKenketa.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnKenketa.ForeColor = System.Drawing.Color.White;
            this.btnKenketa.Location = new System.Drawing.Point(810, 350);
            this.btnKenketa.Name = "btnKenketa";
            this.btnKenketa.Size = new System.Drawing.Size(180, 60);
            this.btnKenketa.TabIndex = 9;
            this.btnKenketa.Text = "- KENKETA";
            this.btnKenketa.UseVisualStyleBackColor = false;
            this.btnKenketa.Click += new System.EventHandler(this.btnKenketa_Click);
            // 
            // btnMostrarRanking
            // 
            this.btnMostrarRanking.BackColor = System.Drawing.Color.Coral;
            this.btnMostrarRanking.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnMostrarRanking.ForeColor = System.Drawing.Color.White;
            this.btnMostrarRanking.Location = new System.Drawing.Point(400, 430);
            this.btnMostrarRanking.Name = "btnMostrarRanking";
            this.btnMostrarRanking.Size = new System.Drawing.Size(300, 60);
            this.btnMostrarRanking.TabIndex = 10;
            this.btnMostrarRanking.Text = "Ikusi Ranking-a";
            this.btnMostrarRanking.UseVisualStyleBackColor = false;
            this.btnMostrarRanking.Click += new System.EventHandler(this.btnMostrarRanking_Click);
            // 
            // btnGuardarPuntuacion
            // 
            this.btnGuardarPuntuacion.BackColor = System.Drawing.Color.Coral;
            this.btnGuardarPuntuacion.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnGuardarPuntuacion.ForeColor = System.Drawing.Color.White;
            this.btnGuardarPuntuacion.Location = new System.Drawing.Point(720, 430);
            this.btnGuardarPuntuacion.Name = "btnGuardarPuntuacion";
            this.btnGuardarPuntuacion.Size = new System.Drawing.Size(270, 60);
            this.btnGuardarPuntuacion.TabIndex = 11;
            this.btnGuardarPuntuacion.Text = "Gorde Puntuazioa";
            this.btnGuardarPuntuacion.UseVisualStyleBackColor = false;
            this.btnGuardarPuntuacion.Click += new System.EventHandler(this.btnGuardarPuntuacion_Click);
            
            // 
            // Matematika
            // 
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(1024, 505);
            this.Controls.Add(this.labelQuestion);
            this.Controls.Add(this.btnOpcion1);
            this.Controls.Add(this.btnOpcion2);
            this.Controls.Add(this.btnOpcion3);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.lblAciertos);
            this.Controls.Add(this.lblTiempo);
            this.Controls.Add(this.btnIniciar);
            this.Controls.Add(this.btnGehiketa);
            this.Controls.Add(this.btnKenketa);
            this.Controls.Add(this.btnMostrarRanking);
            this.Controls.Add(this.btnGuardarPuntuacion);
            this.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Matematika";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelQuestion;
        private System.Windows.Forms.Button btnOpcion1;
        private System.Windows.Forms.Button btnOpcion2;
        private System.Windows.Forms.Button btnOpcion3;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Label lblAciertos;
        private System.Windows.Forms.Label lblTiempo;
        private System.Windows.Forms.Button btnIniciar;
        private System.Windows.Forms.Button btnGehiketa;
        private System.Windows.Forms.Button btnKenketa;
        private System.Windows.Forms.Button btnMostrarRanking;
        private System.Windows.Forms.Button btnGuardarPuntuacion;
        private System.Windows.Forms.Timer cronometro;
    }
}
