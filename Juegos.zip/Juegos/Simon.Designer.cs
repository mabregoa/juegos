﻿namespace Juegos
{
    partial class Simon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGORRIA = new System.Windows.Forms.Button();
            this.btnHORIA = new System.Windows.Forms.Button();
            this.btnBERDEA = new System.Windows.Forms.Button();
            this.btnURDINA = new System.Windows.Forms.Button();
            this.lblPuntuacion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGORRIA
            // 
            this.btnGORRIA.BackColor = System.Drawing.Color.Red;
            this.btnGORRIA.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGORRIA.Location = new System.Drawing.Point(25, 82);
            this.btnGORRIA.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnGORRIA.Name = "btnGORRIA";
            this.btnGORRIA.Size = new System.Drawing.Size(450, 300);
            this.btnGORRIA.TabIndex = 0;
            this.btnGORRIA.Text = "GORRIA";
            this.btnGORRIA.UseVisualStyleBackColor = false;
            this.btnGORRIA.Click += new System.EventHandler(this.btnGORRIA_Click);
            // 
            // btnHORIA
            // 
            this.btnHORIA.BackColor = System.Drawing.Color.Yellow;
            this.btnHORIA.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHORIA.Location = new System.Drawing.Point(485, 82);
            this.btnHORIA.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnHORIA.Name = "btnHORIA";
            this.btnHORIA.Size = new System.Drawing.Size(450, 300);
            this.btnHORIA.TabIndex = 1;
            this.btnHORIA.Text = "HORIA";
            this.btnHORIA.UseVisualStyleBackColor = false;
            this.btnHORIA.Click += new System.EventHandler(this.btnHORIA_Click);
            // 
            // btnBERDEA
            // 
            this.btnBERDEA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnBERDEA.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBERDEA.Location = new System.Drawing.Point(25, 394);
            this.btnBERDEA.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnBERDEA.Name = "btnBERDEA";
            this.btnBERDEA.Size = new System.Drawing.Size(450, 300);
            this.btnBERDEA.TabIndex = 2;
            this.btnBERDEA.Text = "BERDEA";
            this.btnBERDEA.UseVisualStyleBackColor = false;
            this.btnBERDEA.Click += new System.EventHandler(this.btnBERDEA_Click);
            // 
            // btnURDINA
            // 
            this.btnURDINA.BackColor = System.Drawing.Color.Blue;
            this.btnURDINA.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnURDINA.Location = new System.Drawing.Point(485, 394);
            this.btnURDINA.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnURDINA.Name = "btnURDINA";
            this.btnURDINA.Size = new System.Drawing.Size(450, 300);
            this.btnURDINA.TabIndex = 3;
            this.btnURDINA.Text = "URDINA";
            this.btnURDINA.UseVisualStyleBackColor = false;
            this.btnURDINA.Click += new System.EventHandler(this.btnURDINA_Click);
            // 
            // lblPuntuacion
            // 
            this.lblPuntuacion.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPuntuacion.Location = new System.Drawing.Point(21, 9);
            this.lblPuntuacion.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPuntuacion.Name = "lblPuntuacion";
            this.lblPuntuacion.Size = new System.Drawing.Size(904, 46);
            this.lblPuntuacion.TabIndex = 0;
            // 
            // Simon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(1139, 876);
            this.Controls.Add(this.btnHORIA);
            this.Controls.Add(this.btnGORRIA);
            this.Controls.Add(this.btnURDINA);
            this.Controls.Add(this.btnBERDEA);
            this.Controls.Add(this.lblPuntuacion);
            this.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Simon";
            this.Text = "Simon";
            this.Load += new System.EventHandler(this.Simon_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGORRIA;
        private System.Windows.Forms.Button btnHORIA;
        private System.Windows.Forms.Button btnBERDEA;
        private System.Windows.Forms.Button btnURDINA;
        private System.Windows.Forms.Label lblPuntuacion;
    }
}