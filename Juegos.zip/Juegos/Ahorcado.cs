﻿using System;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Juegos
{


    public partial class Ahorcado : Form
    {


        private string palabraOriginal = "";
        private string palabraOculta = "";
        private List<char> letrasIncorrectas = new List<char>();
        private int intentosRestantes;
        private List<string> palabrasDisponibles = new List<string>();
        private List<string> palabrasUsadas = new List<string>();

        public Ahorcado()
        {
            InitializeComponent();
            CargarPalabrasDesdeJSON();
            IniciarJuego(false);
        }

        private void CargarPalabrasDesdeJSON()
        {
            string ruta = Path.Combine(Application.StartupPath, "Ficheros", "Ahorcado.json");
            if (File.Exists(ruta))
            {
                palabrasDisponibles = File.ReadAllLines(ruta).ToList();
            }
            else
            {
                MessageBox.Show("No se encontró el archivo");
            }
            palabrasUsadas.Clear();

        }

        private string ObtenerPalabraAleatoria()
        {
            if (palabrasDisponibles.Count == 0)
            {
                MessageBox.Show("Ez daude gehiago hitzik! Zerrenda berriro hasiko da.");
                // Reiniciar si se han usado todas
                CargarPalabrasDesdeJSON();
            }

            var rand = new Random();
            int index = rand.Next(palabrasDisponibles.Count);
            string palabra = palabrasDisponibles[index].ToUpper();

            palabrasDisponibles.RemoveAt(index);  // Eliminar de las disponibles
            palabrasUsadas.Add(palabra);          // Guardar en usadas

            return palabra;
        }


        private void IniciarJuego(bool esManual)
        {
            letrasIncorrectas.Clear();
            lblErrores.Text = "";
            lblMensaje.Text = "";
            palabraOculta = "";

            if (!esManual)
            {
                var rand = new Random();
                palabraOriginal = ObtenerPalabraAleatoria();
                PrepararPalabra();
            }
            else
            {
                using (var form = new FormPalabraManual())
                {
                    if (form.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(form.Palabra))
                    {
                        palabraOriginal = form.Palabra.ToUpper();
                        PrepararPalabra();
                    }
                }
            }
        }

        private void PrepararPalabra()
        {
            palabraOculta = new string('_', palabraOriginal.Length);
            intentosRestantes = palabraOriginal.Length;
            MostrarPalabra();
        }

        private void MostrarPalabra()
        {
            lblPalabra.Text = string.Join(" ", palabraOculta.ToCharArray());
        }

        private void btnPalabraAleatoria_Click(object sender, EventArgs e)
        {
            IniciarJuego(false);
        }

        private void btnPalabraManual_Click(object sender, EventArgs e)
        {
            IniciarJuego(true);
        }

        private void btnAdivinar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLetra.Text)) return;

            char letra = char.ToUpper(txtLetra.Text[0]);
            txtLetra.Clear();

            if (palabraOriginal.Contains(letra))
            {
                for (int i = 0; i < palabraOriginal.Length; i++)
                {
                    if (palabraOriginal[i] == letra)
                        palabraOculta = palabraOculta.Substring(0, i) + letra + palabraOculta.Substring(i + 1);
                }

                MostrarPalabra();

                if (!palabraOculta.Contains('_'))
                {
                    lblMensaje.Text = "IRABAZI DUZU!";
                    animTimer.Start();
                }
            }
            else
            {
                if (!letrasIncorrectas.Contains(letra))
                {
                    letrasIncorrectas.Add(letra);
                    intentosRestantes--;
                    lblErrores.Text = "LETRA OKERRAK: " + string.Join(" ", letrasIncorrectas);

                    if (intentosRestantes <= 0)
                    {
                        lblMensaje.Text = $"GALDU DUZU! HITZA: {palabraOriginal} DA";
                        palabraOculta = palabraOriginal;
                        MostrarPalabra();
                        animTimer.Start();
                    }
                }
            }
        }

        private void animTimer_Tick(object sender, EventArgs e)
        {
            colorStep = (colorStep + 1) % 360;
            lblMensaje.ForeColor = ColorFromHSV(colorStep, 0.8, 0.9);
        }

        private Color ColorFromHSV(double hue, double saturation, double value)
        {
            int hi = Convert.ToInt32(Math.Floor(hue / 60)) % 6;
            double f = hue / 60 - Math.Floor(hue / 60);
            value *= 255;
            int v = Convert.ToInt32(value);
            int p = Convert.ToInt32(value * (1 - saturation));
            int q = Convert.ToInt32(value * (1 - f * saturation));
            int t = Convert.ToInt32(value * (1 - (1 - f) * saturation));

            switch (hi)
            {
                case 0:
                    return Color.FromArgb(255, v, t, p);
                case 1:
                    return Color.FromArgb(255, q, v, p);
                case 2:
                    return Color.FromArgb(255, p, v, t);
                case 3:
                    return Color.FromArgb(255, p, q, v);
                case 4:
                    return Color.FromArgb(255, t, p, v);
                default:
                    return Color.FromArgb(255, v, p, q);
            }

        }


    }

}
