﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace Juegos
{
    public partial class Simon : Form
    {
        private List<string> secuencia = new List<string>();
        private List<string> inputUsuario = new List<string>();
        private Random random = new Random();
        private int puntuacion = 0;
        private int tiempo = 500;

        public Simon()
        {
            InitializeComponent();
        }

        private async void Simon_Load(object sender, EventArgs e)
        {
            await NuevaRonda();
        }
        private async Task NuevaRonda()
        {
            inputUsuario.Clear();
            string[] colores = { "GORRIA", "BERDEA", "URDINA", "HORIA" };
            secuencia.Add(colores[random.Next(colores.Length)]);
            ActualizarPuntuacion();
            await MostrarSecuencia();
        }

        private async Task MostrarSecuencia()
        {
            HabilitarBotones(false);
            foreach (string color in secuencia)
            {
                await IluminarBoton(color);
                await Task.Delay(300);
            }
            HabilitarBotones(true);
        }

        private async Task IluminarBoton(string color)
        {
            Button btn = ObtenerBoton(color);
            Color original = btn.BackColor;

            btn.BackColor = System.Drawing.Color.White;
            ReproducirSonido(color);
            await Task.Delay(500);
            btn.BackColor = original;
        }

        private void ReproducirSonido(string color)
        {
            try
            {

                var path = System.IO.Path.Combine(Application.StartupPath, "sonido") + "\\" + color + ".wav";
                SoundPlayer player = new SoundPlayer(path);
                player.Play();
            }
            catch
            {
                // En caso de que no se encuentre el archivo
                System.Diagnostics.Debug.WriteLine("No se pudo reproducir el sonido.");
            }
        }

        private Button ObtenerBoton(string color)
        {
            switch (color)
            {
                case "GORRIA":
                    return btnGORRIA;
                case "BERDEA":
                    return btnBERDEA;
                case "URDINA":
                    return btnURDINA;
                case "HORIA":
                    return btnHORIA;

            }
            return null;
        }

        private async void BotonColor_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string color = btn.Name.Replace("btn", "");

            //ReproducirSonido(color);
            inputUsuario.Add(color);

            int i = inputUsuario.Count - 1;
            if (inputUsuario[i].ToUpper() != secuencia[i].ToUpper())
            {
                HabilitarBotones(false);
                MessageBox.Show("¡HUTS EGIN! PUNTUAZIO: " + puntuacion);
                puntuacion = 0;
                secuencia.Clear();
                ActualizarPuntuacion();
                await Task.Delay(1000);
                await NuevaRonda();
                return;
            }

            if (inputUsuario.Count == secuencia.Count)
            {
                puntuacion++;
                await Task.Delay(tiempo);
                await NuevaRonda();
            }
        }

        private void ActualizarPuntuacion()
        {
            lblPuntuacion.Text = $"Puntuación: {puntuacion}";
        }

        private async void Reiniciar()
        {
            puntuacion = 0;
            secuencia.Clear();
            ActualizarPuntuacion();
            await Task.Delay(1000);
            await NuevaRonda();
            return;
        }

        private void HabilitarBotones(bool habilitar)
        {
            btnGORRIA.Enabled = habilitar;
            btnBERDEA.Enabled = habilitar;
            btnURDINA.Enabled = habilitar;
            btnHORIA.Enabled = habilitar;
        }

        private void btnGORRIA_Click(object sender, EventArgs e)
        {
            BotonColor_Click(sender, e);
        }

        private void btnURDINA_Click(object sender, EventArgs e)
        {
            BotonColor_Click(sender, e);
        }

        private void btnBERDEA_Click(object sender, EventArgs e)
        {
            BotonColor_Click(sender, e);
        }

        private void btnHORIA_Click(object sender, EventArgs e)
        {
            BotonColor_Click(sender, e);
        }

     
    }
}
