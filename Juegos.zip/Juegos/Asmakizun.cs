﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Juegos
{
    public partial class Asmakizun : Form
    {
        private readonly JuegoAdivinanzas juego;
        private Timer timer;
        private Timer timerRespuestaCorrecta; // Temporizador para respuesta correcta
        private int tiempoRestante;

        public Asmakizun()
        {
            InitializeComponent();
            juego = new JuegoAdivinanzas("Ficheros\\Asmakizun.json", "medio");
            timer = new System.Windows.Forms.Timer { Interval = 1000 };
            timer.Tick += Timer_Tick;

            timerRespuestaCorrecta = new System.Windows.Forms.Timer { Interval = 2000 }; // 2 segundos
            timerRespuestaCorrecta.Tick += TimerRespuestaCorrecta_Tick;
            ActualizarInterfaz();
        }

        private void ActualizarInterfaz()
        {
            labelPista.Text = juego.ObtenerPistaActual();
            buttonOtraPista.Enabled = juego.HayMasPistas();
            labelResultado.Text = "";
            textBoxRespuesta.Text = "";
            tiempoRestante = 3000;
            timer.Start();
            timerRespuestaCorrecta.Stop();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            tiempoRestante--;
            if (tiempoRestante <= 0)
            {
                timer.Stop();
                MessageBox.Show("Denbora amaitu da!", "Jokoa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                juego.SeleccionarSiguienteadivinanza();
                ActualizarInterfaz();
            }
        }
        private void TimerRespuestaCorrecta_Tick(object sender, EventArgs e)
        {
            timerRespuestaCorrecta.Stop(); // Detener el temporizador
            juego.SeleccionarSiguienteadivinanza();
            ActualizarInterfaz();
        }

        private void buttonResponder_Click(object sender, EventArgs e)
        {
            if (juego.VerificarRespuesta(textBoxRespuesta.Text))
            {
                juego.RegistrarRespuestaCorrecta();
                labelResultado.Text = $"Zuzena! Puntuazioa: {juego.ObtenerPuntuacion()}";
                labelResultado.ForeColor = Color.Green;
                timer.Stop();
                timerRespuestaCorrecta.Start(); //
            }
            else
            {
                labelResultado.Text = "Ez da zuzena. Saiatu berriro!";
                labelResultado.ForeColor = Color.Red;
            }
        }

        private void buttonOtraPista_Click(object sender, EventArgs e)
        {
            juego.SiguientePista();
            labelPista.Text = juego.ObtenerPistaActual();
            buttonOtraPista.Enabled = juego.HayMasPistas();
        }

        private void buttonNuevaadivinanza_Click(object sender, EventArgs e)
        {
            timer.Stop();
            timerRespuestaCorrecta.Stop();
            juego.SeleccionarSiguienteadivinanza();
            ActualizarInterfaz();
        }

        private void btnResolver_Click(object sender, EventArgs e)
        {
            labelResultado.Text = juego.DameRespuesta();
            labelResultado.ForeColor = Color.Red;
            timer.Stop();
            timerRespuestaCorrecta.Stop();
            
        }
    }
}