﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Juegos
{
    public class Matematika_Ranking
    {
        public string Jugador { get; set; }
        public int Puntuacion { get; set; }
        public DateTime Fecha { get; set; }
    }
}
