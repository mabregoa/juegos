﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Text.Json;

namespace Juegos
{
    public class adivinanza
    {
        public string gauza { get; set; }
        public List<string> pistak { get; set; }
    }
    public class JuegoAdivinanzas
    {
        private List<adivinanza> adivinanzas;
        private int adivinanzaIndex;
        private adivinanza adivinanzaActual;
        private int pistaIndex=0;
        private int puntuacion;
        private readonly Random random = new Random();
        private readonly int maxPistas;

        public JuegoAdivinanzas(string rutaArchivo, string dificultad)
        {
            Cargaradivinanzas(rutaArchivo);
            maxPistas = 0;
            switch (dificultad)
            {
                case "facil":
                    maxPistas = 5;
                        break;
                case "medio":
                    maxPistas = 3;
                    break;
                default:
                    maxPistas = 1;
                    break;

            }
            Barajaradivinanzas();
            SeleccionarSiguienteadivinanza();
        }

        public string ObtenerPistaActual() => adivinanzaActual.pistak[pistaIndex];
        public bool HayMasPistas() => pistaIndex < Math.Min(maxPistas, adivinanzaActual.pistak.Count - 1);
        public bool VerificarRespuesta(string respuesta) =>
            respuesta.Trim().Equals(adivinanzaActual.gauza, StringComparison.OrdinalIgnoreCase);

        public string DameRespuesta() =>(adivinanzaActual.gauza);
        public int ObtenerPuntuacion() => puntuacion;

        public void RegistrarRespuestaCorrecta()
        {
            puntuacion += (adivinanzaActual.pistak.Count - pistaIndex) * 10;
        }

        public void SiguientePista()
        {
            if (HayMasPistas())
            {
                pistaIndex++;
            }
        }

        public void SeleccionarSiguienteadivinanza()
        {
            if (adivinanzaIndex >= adivinanzas.Count)
            {
                Barajaradivinanzas();
            }
            adivinanzaActual = adivinanzas[adivinanzaIndex++];
            pistaIndex = 0;
        }

        private void Cargaradivinanzas(string rutaArchivo)
        {
            try
            {
                string json = File.ReadAllText(rutaArchivo);
               
                adivinanzas = JsonSerializer.Deserialize<List<adivinanza>>(json);
                if (adivinanzas == null || adivinanzas.Count == 0)
                {
                    throw new InvalidOperationException("El archivo de adivinanzas está vacío o no es válido.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al cargar las adivinanzas: {ex.Message}", ex);
            }
        }

        private void Barajaradivinanzas()
        {
            for (int i = adivinanzas.Count - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                var temp = adivinanzas[i];
                adivinanzas[i] = adivinanzas[j];
                adivinanzas[j] = temp;
            }
            adivinanzaIndex = 0;
        }
    }
}