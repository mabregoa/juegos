﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Juegos.Clases
{
    public class Preguntas
    {
        public string Pregunta { get; set; }
        public string Respuesta { get; set; } // Mantenido para compatibilidad
        public string[] Respuestas { get; set; } // Nuevo campo para múltiples respuestas
        public string Categoria { get; set; } // Nuevo campo para categoría
    }
}
