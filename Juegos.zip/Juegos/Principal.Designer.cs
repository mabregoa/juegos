﻿namespace Juegos
{
    partial class Principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSimon = new System.Windows.Forms.Button();
            this.btnMemory = new System.Windows.Forms.Button();
            this.btnMatematikak = new System.Windows.Forms.Button();
            this.btnItxi = new System.Windows.Forms.Button();
            this.lblNombreJugador = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLanbideak = new System.Windows.Forms.Button();
            this.btnGalderak = new System.Windows.Forms.Button();
            this.btnAhorcado = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSimon
            // 
            this.btnSimon.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSimon.Location = new System.Drawing.Point(40, 46);
            this.btnSimon.Name = "btnSimon";
            this.btnSimon.Size = new System.Drawing.Size(300, 60);
            this.btnSimon.TabIndex = 11;
            this.btnSimon.Text = "SIMON";
            this.btnSimon.UseVisualStyleBackColor = false;
            this.btnSimon.Click += new System.EventHandler(this.btnSimon_Click);
            // 
            // btnMemory
            // 
            this.btnMemory.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnMemory.Location = new System.Drawing.Point(402, 46);
            this.btnMemory.Name = "btnMemory";
            this.btnMemory.Size = new System.Drawing.Size(300, 60);
            this.btnMemory.TabIndex = 12;
            this.btnMemory.Text = "BIKOTEAK";
            this.btnMemory.UseVisualStyleBackColor = false;
            this.btnMemory.Click += new System.EventHandler(this.btnMemory_Click);
            // 
            // btnMatematikak
            // 
            this.btnMatematikak.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnMatematikak.Location = new System.Drawing.Point(771, 46);
            this.btnMatematikak.Name = "btnMatematikak";
            this.btnMatematikak.Size = new System.Drawing.Size(300, 60);
            this.btnMatematikak.TabIndex = 13;
            this.btnMatematikak.Text = "MATEMATIKAK";
            this.btnMatematikak.UseVisualStyleBackColor = false;
            this.btnMatematikak.Click += new System.EventHandler(this.btnMatematikak_Click);
            // 
            // btnItxi
            // 
            this.btnItxi.BackColor = System.Drawing.Color.SteelBlue;
            this.btnItxi.Location = new System.Drawing.Point(806, 303);
            this.btnItxi.Name = "btnItxi";
            this.btnItxi.Size = new System.Drawing.Size(300, 60);
            this.btnItxi.TabIndex = 14;
            this.btnItxi.Text = "APLIKAZIOA ITXI";
            this.btnItxi.UseVisualStyleBackColor = false;
            this.btnItxi.Click += new System.EventHandler(this.btnItxi_Click);
            // 
            // lblNombreJugador
            // 
            this.lblNombreJugador.AutoSize = true;
            this.lblNombreJugador.Location = new System.Drawing.Point(47, 8);
            this.lblNombreJugador.Name = "lblNombreJugador";
            this.lblNombreJugador.Size = new System.Drawing.Size(0, 35);
            this.lblNombreJugador.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.Location = new System.Drawing.Point(771, 131);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(300, 60);
            this.button1.TabIndex = 17;
            this.button1.Text = "MATEMATIKAK II";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLanbideak
            // 
            this.btnLanbideak.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnLanbideak.Location = new System.Drawing.Point(402, 131);
            this.btnLanbideak.Name = "btnLanbideak";
            this.btnLanbideak.Size = new System.Drawing.Size(300, 60);
            this.btnLanbideak.TabIndex = 18;
            this.btnLanbideak.Text = "LANBIDEAK";
            this.btnLanbideak.UseVisualStyleBackColor = false;
            this.btnLanbideak.Click += new System.EventHandler(this.btnLanbideak_Click);
            // 
            // btnGalderak
            // 
            this.btnGalderak.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnGalderak.Location = new System.Drawing.Point(40, 131);
            this.btnGalderak.Name = "btnGalderak";
            this.btnGalderak.Size = new System.Drawing.Size(300, 60);
            this.btnGalderak.TabIndex = 19;
            this.btnGalderak.Text = "GALDERAK";
            this.btnGalderak.UseVisualStyleBackColor = false;
            this.btnGalderak.Click += new System.EventHandler(this.btnGalderak_Click);
            // 
            // btnAhorcado
            // 
            this.btnAhorcado.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAhorcado.Location = new System.Drawing.Point(40, 229);
            this.btnAhorcado.Name = "btnAhorcado";
            this.btnAhorcado.Size = new System.Drawing.Size(300, 60);
            this.btnAhorcado.TabIndex = 20;
            this.btnAhorcado.Text = "URKATUA";
            this.btnAhorcado.UseVisualStyleBackColor = false;
            this.btnAhorcado.Click += new System.EventHandler(this.btnAhorcado_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(1118, 375);
            this.Controls.Add(this.btnAhorcado);
            this.Controls.Add(this.btnGalderak);
            this.Controls.Add(this.btnLanbideak);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblNombreJugador);
            this.Controls.Add(this.btnItxi);
            this.Controls.Add(this.btnMatematikak);
            this.Controls.Add(this.btnMemory);
            this.Controls.Add(this.btnSimon);
            this.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Principal";
            this.Text = "JOKOAK";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Principal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSimon;
        private System.Windows.Forms.Button btnMemory;
        private System.Windows.Forms.Button btnMatematikak;
        private System.Windows.Forms.Button btnItxi;
        private System.Windows.Forms.Label lblNombreJugador;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnLanbideak;
        private System.Windows.Forms.Button btnGalderak;
        private System.Windows.Forms.Button btnAhorcado;
    }
}

