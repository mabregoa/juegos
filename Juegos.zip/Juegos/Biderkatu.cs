﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juegos
{
    public partial class Biderkatu : Form
    {
        public Biderkatu()
        {
            InitializeComponent();
            GenerarPregunta();
        }


        private int num1, num2, respuestaCorrecta;
        private Random random = new Random();

        private void btnComprobar_Click(object sender, EventArgs e)
        {

        }

        private void GenerarPregunta()
        {
            num1 = random.Next(1, 10);
            num2 = random.Next(1, 10);
            respuestaCorrecta = num1 * num2;
            lblPregunta.Text = $"{num1} x {num2} = ?";

            // Generar respuestas aleatorias (una correcta y dos incorrectas)
            int[] respuestas = { respuestaCorrecta, respuestaCorrecta + random.Next(-5, 5), respuestaCorrecta + random.Next(-5, 5) };
            // Asegurar que las respuestas incorrectas sean diferentes de la correcta
            while (respuestas[1] == respuestaCorrecta) respuestas[1] = respuestaCorrecta + random.Next(-5, 5);
            while (respuestas[2] == respuestaCorrecta || respuestas[2] == respuestas[1]) respuestas[2] = respuestaCorrecta + random.Next(-5, 5);

            // Mezclar las respuestas aleatoriamente
            for (int i = 0; i < respuestas.Length; i++)
            {
                int temp = respuestas[i];
                int randomIndex = random.Next(respuestas.Length);
                respuestas[i] = respuestas[randomIndex];
                respuestas[randomIndex] = temp;
            }

            // Asignar respuestas a los radio buttons
            radioButton1.Text = respuestas[0].ToString();
            radioButton2.Text = respuestas[1].ToString();
            radioButton3.Text = respuestas[2].ToString();

            // Desmarcar todos los radio buttons
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;

            lblResultado.Text = "";
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int respuestaUsuario = -1; // Inicializar con un valor inválido

            // Obtener la respuesta seleccionada por el usuario
            if (radioButton1.Checked) respuestaUsuario = int.Parse(radioButton1.Text);
            else if (radioButton2.Checked) respuestaUsuario = int.Parse(radioButton2.Text);
            else if (radioButton3.Checked) respuestaUsuario = int.Parse(radioButton3.Text);

            if (respuestaUsuario == respuestaCorrecta)
            {
                lblResultado.Text = "¡ONDO!";
                GenerarPregunta();
            }
            else
            {
                lblResultado.Text = $"GAIZKI.";
            }

            
        }
    }
}
