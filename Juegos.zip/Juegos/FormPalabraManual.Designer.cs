﻿namespace Juegos
{
    using System.Windows.Forms;
    partial class FormPalabraManual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private TextBox txtPalabra;
        private Button btnAceptar;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalabra = new System.Windows.Forms.TextBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.txtPalabra.Location = new System.Drawing.Point(20, 20);
            this.txtPalabra.Size = new System.Drawing.Size(200, 23);

            this.btnAceptar.Location = new System.Drawing.Point(80, 60);
            this.btnAceptar.Size = new System.Drawing.Size(75, 25);
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);

            this.ClientSize = new System.Drawing.Size(250, 110);
            this.Controls.Add(this.txtPalabra);
            this.Controls.Add(this.btnAceptar);
            this.Text = "Introduce la palabra";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}