﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Juegos
{
    partial class Asmakizun
    {
        private Label labelPista;
        private Label labelResultado;
        private TextBox textBoxRespuesta;
        private Button btnComprobar;
        private Button buttonOtraPista;
        private Button btnNuevaadivinanza;

        private void InitializeComponent()
        {
            this.labelPista = new System.Windows.Forms.Label();
            this.labelResultado = new System.Windows.Forms.Label();
            this.textBoxRespuesta = new System.Windows.Forms.TextBox();
            this.btnComprobar = new System.Windows.Forms.Button();
            this.buttonOtraPista = new System.Windows.Forms.Button();
            this.btnNuevaadivinanza = new System.Windows.Forms.Button();
            this.btnResolver = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelPista
            // 
            this.labelPista.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.labelPista.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelPista.Location = new System.Drawing.Point(30, 30);
            this.labelPista.Name = "labelPista";
            this.labelPista.Size = new System.Drawing.Size(640, 80);
            this.labelPista.TabIndex = 0;
            this.labelPista.Text = "Pista...";
            // 
            // labelResultado
            // 
            this.labelResultado.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelResultado.ForeColor = System.Drawing.Color.Black;
            this.labelResultado.Location = new System.Drawing.Point(30, 312);
            this.labelResultado.Name = "labelResultado";
            this.labelResultado.Size = new System.Drawing.Size(640, 40);
            this.labelResultado.TabIndex = 3;
            // 
            // textBoxRespuesta
            // 
            this.textBoxRespuesta.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.textBoxRespuesta.Location = new System.Drawing.Point(30, 130);
            this.textBoxRespuesta.Name = "textBoxRespuesta";
            this.textBoxRespuesta.Size = new System.Drawing.Size(640, 43);
            this.textBoxRespuesta.TabIndex = 1;
            // 
            // btnComprobar
            // 
            this.btnComprobar.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnComprobar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComprobar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.btnComprobar.ForeColor = System.Drawing.Color.White;
            this.btnComprobar.Location = new System.Drawing.Point(30, 190);
            this.btnComprobar.Name = "btnComprobar";
            this.btnComprobar.Size = new System.Drawing.Size(640, 50);
            this.btnComprobar.TabIndex = 2;
            this.btnComprobar.Text = "✅ Zuzendu";
            this.btnComprobar.UseVisualStyleBackColor = false;
            this.btnComprobar.Click += new System.EventHandler(this.buttonResponder_Click);
            // 
            // buttonOtraPista
            // 
            this.buttonOtraPista.BackColor = System.Drawing.Color.LightSteelBlue;
            this.buttonOtraPista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOtraPista.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.buttonOtraPista.Location = new System.Drawing.Point(30, 388);
            this.buttonOtraPista.Name = "buttonOtraPista";
            this.buttonOtraPista.Size = new System.Drawing.Size(200, 45);
            this.buttonOtraPista.TabIndex = 4;
            this.buttonOtraPista.Text = "💡 Beste pista bat";
            this.buttonOtraPista.UseVisualStyleBackColor = false;
            this.buttonOtraPista.Click += new System.EventHandler(this.buttonOtraPista_Click);
            // 
            // btnNuevaadivinanza
            // 
            this.btnNuevaadivinanza.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnNuevaadivinanza.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevaadivinanza.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnNuevaadivinanza.ForeColor = System.Drawing.Color.White;
            this.btnNuevaadivinanza.Location = new System.Drawing.Point(391, 388);
            this.btnNuevaadivinanza.Name = "btnNuevaadivinanza";
            this.btnNuevaadivinanza.Size = new System.Drawing.Size(279, 45);
            this.btnNuevaadivinanza.TabIndex = 5;
            this.btnNuevaadivinanza.Text = "🔄 Hurrengo Asmakizun";
            this.btnNuevaadivinanza.UseVisualStyleBackColor = false;
            this.btnNuevaadivinanza.Click += new System.EventHandler(this.buttonNuevaadivinanza_Click);
            // 
            // btnResolver
            // 
            this.btnResolver.BackColor = System.Drawing.Color.Coral;
            this.btnResolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResolver.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.btnResolver.ForeColor = System.Drawing.Color.White;
            this.btnResolver.Location = new System.Drawing.Point(30, 246);
            this.btnResolver.Name = "btnResolver";
            this.btnResolver.Size = new System.Drawing.Size(640, 50);
            this.btnResolver.TabIndex = 6;
            this.btnResolver.Text = "Ikusi erantzuna";
            this.btnResolver.UseVisualStyleBackColor = false;
            this.btnResolver.Click += new System.EventHandler(this.btnResolver_Click);
            // 
            // Asmakizun
            // 
            this.AcceptButton = this.btnComprobar;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(700, 500);
            this.Controls.Add(this.btnResolver);
            this.Controls.Add(this.labelPista);
            this.Controls.Add(this.textBoxRespuesta);
            this.Controls.Add(this.btnComprobar);
            this.Controls.Add(this.labelResultado);
            this.Controls.Add(this.buttonOtraPista);
            this.Controls.Add(this.btnNuevaadivinanza);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Asmakizun";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adivina la Profesión";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private Button btnResolver;
    }
}
