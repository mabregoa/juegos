﻿using System;
using System.Windows.Forms;

namespace Juegos
{
    public partial class FormNombreJugador : Form
    {
        public string NombreJugador { get; private set; }

        public FormNombreJugador()
        {
            InitializeComponent();
        }

        private void buttonAceptar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                NombreJugador = txtNombre.Text.Trim();
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Mesedez, idatzi zure izena.");
            }
        }

        public void EstablecerNombre(string nombreEtiqueta)
        {
            if (nombreEtiqueta.Length != 0) 
                {
                lblEtiqueta.Text = nombreEtiqueta;
            }
        }

        private void FormNombreJugador_Load(object sender, EventArgs e)
        {

        }
    }
}
