﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Juegos
{
    public partial class bikoteak : Form
    {
        private List<string> imagenes = new List<string>();
        // Lista para rastrear las imágenes asignadas a cada Label
        private List<string> cartas;
        // Lista de Labels (cartas)
        private List<Label> labels = new List<Label>();
        // Variables para la lógica del juego
        private Label primeraCarta = null;
        private Label segundaCarta = null;
        private int parejasEncontradas = 0;
        private int numeroIntentos;
        private bool bloqueo = false;

        public bikoteak()
        {
            InitializeComponent();
            ConfigurarJuego();
        }
        private void ConfigurarJuego()
        {
            lblFinal.Text = "";
            // Ruta de las imágenes (ajusta según tu carpeta)
            string rutaImagenes = System.IO.Path.Combine(Application.StartupPath, "Imagenes") + "\\";
            imagenes.Clear();
            // Cargar 8 imágenes (cada una se duplica para las parejas)
            for (int i = 1; i <= 8; i++)
            {
                imagenes.Add(rutaImagenes + $"img{i}.png");
                imagenes.Add(rutaImagenes + $"img{i}.png");
            }

            // Barajar las imágenes
            cartas = imagenes.OrderBy(x => Guid.NewGuid()).ToList();

            // Crear la cuadrícula de 4x4
            int espacio = 15;
            int tamañoCarta = 140;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Label carta = new Label
                    {
                        Size = new Size(tamañoCarta, tamañoCarta),
                        Location = new Point(espacio + j * (tamañoCarta + espacio), espacio + i * (tamañoCarta + espacio)),
                        BackColor = Color.Gray, // Color de la carta "tapada"
                        Tag = cartas[i * 4 + j], // Guardar la ruta de la imagen en Tag
                        Cursor = Cursors.Hand,
                        Name="Carta " + i.ToString() + j.ToString()
                    };
                    carta.Click += Carta_Click;
                    labels.Add(carta);
                    this.Controls.Add(carta);
                }
            }

            // Ajustar tamaño del formulario
            this.ClientSize = new Size(4 * (tamañoCarta + espacio) + espacio + espacio, 4 * (tamañoCarta + espacio) + espacio + espacio);
        }

        private void Carta_Click(object sender, EventArgs e)
        {
            if (bloqueo) return; // Evitar clics durante animación
            Label cartaActual = sender as Label;

            // Evitar seleccionar la misma carta dos veces
            if (cartaActual == primeraCarta || cartaActual.Image != null) return;

            // Mostrar la imagen de la carta
            cartaActual.Image = Image.FromFile(cartaActual.Tag.ToString());
            cartaActual.Image = ResizeImage(cartaActual.Image, cartaActual.Width, cartaActual.Height);

            if (primeraCarta == null)
            {
                primeraCarta = cartaActual;
            }
            else
            {
                segundaCarta = cartaActual;
                bloqueo = true;

                numeroIntentos++;

                // Verificar si son pareja
                if (primeraCarta.Tag.ToString() == segundaCarta.Tag.ToString())
                {
                    // Pareja encontrada
                    parejasEncontradas++;
                    primeraCarta = null;
                    segundaCarta = null;
                    bloqueo = false;

                    // Verificar si se ganó el juego
                    if (parejasEncontradas == 8)
                    {
                        lblFinal.Text = "¡ZORIONAK, IRABAZI DUZU!!!!" + Environment.NewLine + "SAIALDIAK: " + numeroIntentos.ToString();
                    }
                }
                else
                {

                    // No son pareja, ocultar después de un segundo
                    Timer temporizador = new Timer { Interval = 1000 };
                    temporizador.Tick += (s, args) =>
                    {
                        primeraCarta.Image = null;
                        segundaCarta.Image = null;
                        primeraCarta = null;
                        segundaCarta = null;
                        bloqueo = false;
                        temporizador.Stop();
                    };
                    temporizador.Start();
                }
            }
        }

        // Método para redimensionar imágenes al tamaño de la carta
        private Image ResizeImage(Image img, int width, int height)
        {
            Bitmap resized = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(resized))
            {
                g.DrawImage(img, 0, 0, width, height);
            }
            return resized;
        }

        private void limpiarJuego()
        {
            foreach (Label a in labels)
            {
                    this.Controls.Remove(a);
                
            }
        }

        private void bikoteak_Load(object sender, EventArgs e)
        {

        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            limpiarJuego();
            ConfigurarJuego();
        }

        private void btnAtera_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
