﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juegos
{
    public partial class FormPalabraManual : Form
    {




        public string Palabra => txtPalabra.Text;

        public FormPalabraManual()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtPalabra.Text))
                this.DialogResult = DialogResult.OK;
        }
    }
}
