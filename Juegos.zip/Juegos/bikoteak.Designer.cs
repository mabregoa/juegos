﻿using System.Drawing;
using System.Windows.Forms;

namespace Juegos
{
    partial class bikoteak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFinal = new System.Windows.Forms.Label();
            this.btnIniciar = new System.Windows.Forms.Button();
            this.btnAtera = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFinal
            // 
            this.lblFinal.AutoSize = true;
            this.lblFinal.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinal.Location = new System.Drawing.Point(805, 167);
            this.lblFinal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblFinal.Name = "lblFinal";
            this.lblFinal.Size = new System.Drawing.Size(0, 42);
            this.lblFinal.TabIndex = 1;
            // 
            // btnIniciar
            // 
            this.btnIniciar.BackColor = System.Drawing.Color.SteelBlue;
            this.btnIniciar.Location = new System.Drawing.Point(791, 9);
            this.btnIniciar.Name = "btnIniciar";
            this.btnIniciar.Size = new System.Drawing.Size(310, 60);
            this.btnIniciar.TabIndex = 8;
            this.btnIniciar.Text = "JOLASA HASTEA";
            this.btnIniciar.UseVisualStyleBackColor = false;
            this.btnIniciar.Click += new System.EventHandler(this.btnIniciar_Click);
            // 
            // btnAtera
            // 
            this.btnAtera.BackColor = System.Drawing.Color.SteelBlue;
            this.btnAtera.Location = new System.Drawing.Point(791, 75);
            this.btnAtera.Name = "btnAtera";
            this.btnAtera.Size = new System.Drawing.Size(310, 60);
            this.btnAtera.TabIndex = 9;
            this.btnAtera.Text = "APLIKAZIOA ITXI";
            this.btnAtera.UseVisualStyleBackColor = false;
            this.btnAtera.Click += new System.EventHandler(this.btnAtera_Click);
            // 
            // bikoteak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(1131, 868);
            this.Controls.Add(this.btnAtera);
            this.Controls.Add(this.btnIniciar);
            this.Controls.Add(this.lblFinal);
            this.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "bikoteak";
            this.Text = "BIKOTEAK";
            this.Load += new System.EventHandler(this.bikoteak_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblFinal;
        private Button btnIniciar;
        private Button btnAtera;
    }
}