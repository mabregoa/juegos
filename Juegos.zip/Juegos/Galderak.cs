﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using Juegos.Clases;

namespace Juegos
{
    public partial class Galderak : Form
    {
        private List<Preguntas> preguntas;
        private List<int> preguntasMostradas = new List<int>();
        private List<(string Nombre, int Puntos)> jugadores = new List<(string, int)>();
        private int jugadorActual = 0;
        private int numeroJugadores;
        private string rutaGalderak = Path.Combine(Application.StartupPath, "Ficheros", "Galderak.json");
        private Random random = new Random();
        private Timer temporizador;
       // private int tiempoRestante = 30; // 30 segundos por pregunta

        public Galderak()
        {
            InitializeComponent();
            ConfigurarInterfaz();
            PedirNumeroJugadores();
            PedirNombres();
            CargarPreguntas();
            //ConfigurarTemporizador();
            preguntasMostradas.Clear();
            MostrarPregunta();
        }

        // Añadir al inicio de la clase Galderak
        private int CalcularDistanciaLevenshtein(string a, string b)
        {
            if (string.IsNullOrEmpty(a) && string.IsNullOrEmpty(b)) return 0;
            if (string.IsNullOrEmpty(a)) return b.Length;
            if (string.IsNullOrEmpty(b)) return a.Length;

            int[,] matriz = new int[a.Length + 1, b.Length + 1];

            for (int i = 0; i <= a.Length; i++) matriz[i, 0] = i;
            for (int j = 0; j <= b.Length; j++) matriz[0, j] = j;

            for (int i = 1; i <= a.Length; i++)
            {
                for (int j = 1; j <= b.Length; j++)
                {
                    int costo = (a[i - 1] == b[j - 1]) ? 0 : 1;
                    matriz[i, j] = Math.Min(
                        Math.Min(matriz[i - 1, j] + 1, matriz[i, j - 1] + 1),
                        matriz[i - 1, j - 1] + costo);
                }
            }

            return matriz[a.Length, b.Length];
        }

        private void ConfigurarInterfaz()
        {
            // Etiqueta para resultado
            lblResultado = new Label
            {
                Location = new Point(50, 300),
                Size = new Size(400, 30),
                Font = new Font("Arial", 12),
                TextAlign = ContentAlignment.MiddleCenter
            };
            Controls.Add(lblResultado);

            // Botón siguiente
            btnSiguiente = new Button
            {
                Text = "Siguiente Pregunta",
                Location = new Point(50, 340),
                Size = new Size(150, 30),
                Enabled = false
            };
            btnSiguiente.Click += BtnSiguiente_Click;
            Controls.Add(btnSiguiente);

            // Modificar botón responder
            btnResponder.Enabled = true;
        }

        private void PedirNumeroJugadores()
        {
            using (var form = new Form())
            {
                form.Text = "Número de jugadores";
                var numericUpDown = new NumericUpDown
                {
                    Minimum = 1,
                    Maximum = 10,
                    Location = new Point(50, 50),
                    Value = 2
                };
                var btnAceptar = new Button
                {
                    Text = "Aceptar",
                    Location = new Point(50, 100),
                    DialogResult = DialogResult.OK
                };
                form.Controls.AddRange(new Control[] { numericUpDown, btnAceptar });
                form.AcceptButton = btnAceptar;
                form.Size = new Size(200, 200);

                if (form.ShowDialog() == DialogResult.OK)
                {
                    numeroJugadores = (int)numericUpDown.Value;
                }
                else
                {
                    numeroJugadores = 2; // Valor por defecto
                }
            }
        }

        private void PedirNombres()
        {
            for (int i = 0; i < numeroJugadores; i++)
            {
                var formularioNombre = new FormNombreJugador();
                formularioNombre.EstablecerNombre($"Nombre jugador {i + 1}");
                if (formularioNombre.ShowDialog() == DialogResult.OK)
                {
                    string nombre = string.IsNullOrWhiteSpace(formularioNombre.NombreJugador)
                        ? $"Jugador {i + 1}"
                        : formularioNombre.NombreJugador;
                    jugadores.Add((nombre, 0));
                }
            }
        }

        private void CargarPreguntas()
        {
            try
            {
                string json = File.ReadAllText(rutaGalderak);
                preguntas = JsonSerializer.Deserialize<List<Preguntas>>(json);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al leer el archivo JSON: " + ex.Message);
                preguntas = new List<Preguntas>();
            }
        }

        //private void ConfigurarTemporizador()
        //{
        //    temporizador = new Timer { Interval = 1000 };
        //    temporizador.Tick += (s, e) =>
        //    {
        //        //tiempoRestante--;
        //        lblTurno.Text = $"Tiempo: {tiempoRestante}s | Turno de {jugadores[jugadorActual].Nombre} | " +
        //                       string.Join(" | ", jugadores.Select(j => $"{j.Nombre}: {j.Puntos}"));
        //        if (tiempoRestante <= 0)
        //        {
        //            temporizador.Stop();
        //            lblResultado.Text = "⏰ ¡Tiempo agotado!";
        //            lblResultado.ForeColor = Color.Red;
        //            btnSiguiente.Enabled = true;
        //            btnResponder.Enabled = false;
        //            jugadorActual = (jugadorActual + 1) % numeroJugadores;
        //        }
        //    };
        //}

        private void MostrarPregunta()
        {
            if (preguntasMostradas.Count == preguntas.Count)
            {
                MostrarResultadoFinal();
                return;
            }

            int indicePregunta;
            do
            {
                indicePregunta = random.Next(0, preguntas.Count);
            } while (preguntasMostradas.Contains(indicePregunta));

            lblPregunta.Text = preguntas[indicePregunta].Pregunta;
            lblCategoria.Text = $"Categoría: {preguntas[indicePregunta].Categoria ?? "Todas"}";
            lblTurno.Text = $"Tiempo: s | Turno de {jugadores[jugadorActual].Nombre} | " +
                           string.Join(" | ", jugadores.Select(j => $"{j.Nombre}: {j.Puntos}"));
            txtRespuesta.Text = "";
            preguntasMostradas.Add(indicePregunta);
            txtRespuesta.Focus();

            // Reiniciar temporizador
            //tiempoRestante = 30;
            //temporizador.Start();
            //lblResultado.Text = "";
            btnResponder.Enabled = true;
            btnSiguiente.Enabled = false;
        }

        private void btnResponder_Click(object sender, EventArgs e)
        {
            //temporizador.Stop();
            int indicePreguntaActual = preguntasMostradas.Last();
            string respuestaUsuario = txtRespuesta.Text.Trim().ToLower();

            // Obtener todas las respuestas válidas (para soportar múltiples respuestas, que añadiremos después)
            string[] respuestasCorrectas = preguntas[indicePreguntaActual].Respuestas ?? new[] { preguntas[indicePreguntaActual].Respuesta };

            bool esCorrecta = false;
            string respuestaCorrectaMostrada = respuestasCorrectas[0]; // Para mostrar en caso de error

            foreach (var respuestaCorrecta in respuestasCorrectas)
            {
                if (respuestaUsuario == respuestaCorrecta.ToLower() ||
                    CalcularDistanciaLevenshtein(respuestaUsuario, respuestaCorrecta.ToLower()) <= 2)
                {
                    esCorrecta = true;
                    break;
                }
            }

            if (esCorrecta)
            {
                int puntos = 1;
               // int puntos = tiempoRestante; // Puntos basados en tiempo restante
                lblResultado.Text = $"✅ ¡Correcto! +{puntos} puntos";
                lblResultado.ForeColor = Color.Green;
                jugadores[jugadorActual] = (jugadores[jugadorActual].Nombre, jugadores[jugadorActual].Puntos + puntos);
            }
            else
            {
                lblResultado.Text = $"❌ Incorrecto. Era: {respuestaCorrectaMostrada}";
                lblResultado.ForeColor = Color.Red;
                jugadorActual = (jugadorActual + 1) % numeroJugadores;
            }

            btnResponder.Enabled = false;
            btnSiguiente.Enabled = true;
        }

        private void BtnSiguiente_Click(object sender, EventArgs e)
        {
            MostrarPregunta();
        }

        private void MostrarResultadoFinal()
        {
            temporizador.Stop();
            var ganador = jugadores.OrderByDescending(j => j.Puntos).First();
            string mensaje = "📊 Puntuación final:\n\n" +
                            string.Join("\n", jugadores.Select(j => $"{j.Nombre}: {j.Puntos}")) + "\n\n" +
                            (jugadores.All(j => j.Puntos == ganador.Puntos) ? "🤝 ¡Empate!" : $"🏆 ¡Gana {ganador.Nombre}!");

            GuardarPuntuacionAlta(ganador.Nombre, ganador.Puntos);
            MessageBox.Show(mensaje, "Fin del juego");
            Application.Exit();
        }

        private void GuardarPuntuacionAlta(string nombre, int puntos)
        {
            var rutaPuntuaciones = Path.Combine(Application.StartupPath, "Ficheros", "Puntuaciones.json");
            List<(string Nombre, int Puntos)> puntuaciones = new List<(string, int)>();

            if (File.Exists(rutaPuntuaciones))
            {
                string json = File.ReadAllText(rutaPuntuaciones);
                puntuaciones = JsonSerializer.Deserialize<List<(string, int)>>(json);
            }

            puntuaciones.Add((nombre, puntos));
            puntuaciones = puntuaciones.OrderByDescending(p => p.Puntos).Take(10).ToList();
            File.WriteAllText(rutaPuntuaciones, JsonSerializer.Serialize(puntuaciones));
        }
    }
}