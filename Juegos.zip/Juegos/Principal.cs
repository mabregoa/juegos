﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juegos
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        

        private void btnSimon_Click(object sender, EventArgs e)
        {
            Simon formularioSecundario = new Simon();

            // Muestra el formulario
            formularioSecundario.Show();
        }

        private void btnMatematikak_Click(object sender, EventArgs e)
        {
            Matematika formularioSecundario = new Matematika();

            // Muestra el formulario
            formularioSecundario.Show();
        }

        private void btnMemory_Click(object sender, EventArgs e)
        {
            bikoteak FORMU = new bikoteak();
            FORMU.Show();
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            
        }

        private void btnItxi_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Biderkatu B = new Biderkatu();
            B.Show();
        }

        private void btnLanbideak_Click(object sender, EventArgs e)
        {
            Asmakizun B = new Asmakizun();
            B.Show();
        }

        private void btnGalderak_Click(object sender, EventArgs e)
        {
            Galderak B = new Galderak();
            B.Show();
        }

        private void btnAhorcado_Click(object sender, EventArgs e)
        {
            Ahorcado a = new Ahorcado();
            a.Show();
        }
    }
}
