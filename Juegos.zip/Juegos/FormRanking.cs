﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juegos
{
    public partial class FormRanking : Form
    {
        public FormRanking(List<Matematika_Ranking> ranking)
        {
            InitializeComponent();
            MostrarRanking(ranking);
        }

        private void MostrarRanking(List<Matematika_Ranking> ranking)
        {
            // Crea una tabla para mostrar los datos del ranking
            DataTable tablaRanking = new DataTable();
            tablaRanking.Columns.Add("Posición", typeof(int));
            tablaRanking.Columns.Add("Jugador", typeof(string));
            tablaRanking.Columns.Add("Puntuación", typeof(int));
            tablaRanking.Columns.Add("Fecha", typeof(DateTime));

            // Agrega los datos del ranking a la tabla
            for (int i = 0; i < ranking.Count; i++)
            {
                tablaRanking.Rows.Add(i + 1, ranking[i].Jugador, ranking[i].Puntuacion, ranking[i].Fecha);
            }

            // Asigna la tabla al DataGridView
            dataGridViewRanking.DataSource = tablaRanking;

            // Ajusta el ancho de las columnas
            dataGridViewRanking.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}