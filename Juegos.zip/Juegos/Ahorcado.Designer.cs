﻿namespace Juegos
{
    // Form1.Designer.cs
    partial class Ahorcado
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnPalabraAleatoria;
        private System.Windows.Forms.Button btnPalabraManual;
        private System.Windows.Forms.Label lblPalabra;
        private System.Windows.Forms.TextBox txtLetra;
        private System.Windows.Forms.Label lblErrores;
        private System.Windows.Forms.Label lblMensaje;
        private System.Windows.Forms.Timer animTimer;
        private int colorStep = 0;

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnPalabraAleatoria = new System.Windows.Forms.Button();
            this.btnPalabraManual = new System.Windows.Forms.Button();
            this.lblPalabra = new System.Windows.Forms.Label();
            this.txtLetra = new System.Windows.Forms.TextBox();
            this.lblErrores = new System.Windows.Forms.Label();
            this.lblMensaje = new System.Windows.Forms.Label();
            this.animTimer = new System.Windows.Forms.Timer(this.components);
            this.btnAdivinar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPalabraAleatoria
            // 
            this.btnPalabraAleatoria.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnPalabraAleatoria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPalabraAleatoria.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPalabraAleatoria.ForeColor = System.Drawing.Color.White;
            this.btnPalabraAleatoria.Location = new System.Drawing.Point(30, 20);
            this.btnPalabraAleatoria.Name = "btnPalabraAleatoria";
            this.btnPalabraAleatoria.Size = new System.Drawing.Size(285, 47);
            this.btnPalabraAleatoria.TabIndex = 0;
            this.btnPalabraAleatoria.Text = "AUSAZKO HITZA";
            this.btnPalabraAleatoria.UseVisualStyleBackColor = false;
            this.btnPalabraAleatoria.Click += new System.EventHandler(this.btnPalabraAleatoria_Click);
            // 
            // btnPalabraManual
            // 
            this.btnPalabraManual.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnPalabraManual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPalabraManual.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPalabraManual.ForeColor = System.Drawing.Color.White;
            this.btnPalabraManual.Location = new System.Drawing.Point(343, 20);
            this.btnPalabraManual.Name = "btnPalabraManual";
            this.btnPalabraManual.Size = new System.Drawing.Size(269, 47);
            this.btnPalabraManual.TabIndex = 1;
            this.btnPalabraManual.Text = "HITZA SARTU";
            this.btnPalabraManual.UseVisualStyleBackColor = false;
            this.btnPalabraManual.Click += new System.EventHandler(this.btnPalabraManual_Click);
            // 
            // lblPalabra
            // 
            this.lblPalabra.Font = new System.Drawing.Font("Segoe UI", 22F);
            this.lblPalabra.Location = new System.Drawing.Point(30, 85);
            this.lblPalabra.Name = "lblPalabra";
            this.lblPalabra.Size = new System.Drawing.Size(500, 50);
            this.lblPalabra.TabIndex = 2;
            // 
            // txtLetra
            // 
            this.txtLetra.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.txtLetra.Location = new System.Drawing.Point(30, 153);
            this.txtLetra.MaxLength = 1;
            this.txtLetra.Name = "txtLetra";
            this.txtLetra.Size = new System.Drawing.Size(93, 52);
            this.txtLetra.TabIndex = 3;
            // 
            // lblErrores
            // 
            this.lblErrores.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrores.ForeColor = System.Drawing.Color.Red;
            this.lblErrores.Location = new System.Drawing.Point(31, 250);
            this.lblErrores.Name = "lblErrores";
            this.lblErrores.Size = new System.Drawing.Size(581, 50);
            this.lblErrores.TabIndex = 5;
            // 
            // lblMensaje
            // 
            this.lblMensaje.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblMensaje.Location = new System.Drawing.Point(31, 319);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(581, 55);
            this.lblMensaje.TabIndex = 6;
            // 
            // animTimer
            // 
            this.animTimer.Tick += new System.EventHandler(this.animTimer_Tick);
            // 
            // btnAdivinar
            // 
            this.btnAdivinar.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnAdivinar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdivinar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.btnAdivinar.ForeColor = System.Drawing.Color.White;
            this.btnAdivinar.Location = new System.Drawing.Point(145, 153);
            this.btnAdivinar.Name = "btnAdivinar";
            this.btnAdivinar.Size = new System.Drawing.Size(467, 50);
            this.btnAdivinar.TabIndex = 7;
            this.btnAdivinar.Text = "✅ Zuzendu";
            this.btnAdivinar.UseVisualStyleBackColor = false;
            this.btnAdivinar.Click += new System.EventHandler(this.btnAdivinar_Click);
            // 
            // Ahorcado
            // 
            this.AcceptButton = this.btnAdivinar;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(732, 399);
            this.Controls.Add(this.btnAdivinar);
            this.Controls.Add(this.btnPalabraAleatoria);
            this.Controls.Add(this.btnPalabraManual);
            this.Controls.Add(this.lblPalabra);
            this.Controls.Add(this.txtLetra);
            this.Controls.Add(this.lblErrores);
            this.Controls.Add(this.lblMensaje);
            this.Name = "Ahorcado";
            this.Text = "Juego del Ahorcado";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button btnAdivinar;
    }

}