﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace Juegos
{
    public partial class Matematika : Form
    {
        private Random random = new Random();
        private int respuestaCorrecta;
        private int aciertos;
        private int aciertosTotales;
        private int tiempo;
        private List<Matematika_Ranking> ranking = new List<Matematika_Ranking>();
        private string rutaRanking = System.IO.Path.Combine(Application.StartupPath) + "\\Ranking\\ranking.json";
        private int numeroInicial = 1;
        private int numeroFinal = 100;
        bool sumarSeleccionado = false;
        bool restarSeleccionado = false;
        private int errores = 0;
        private string nombreJugador = "";


        public Matematika()
        {
            InitializeComponent();
            seleccionarkenketa();
            selecionarGehiketa();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            aciertos = 0;
            errores = 0;
            tiempo = 120;
            btnGuardarPuntuacion.Enabled = true;
            lblAciertos.Text = "ASMATUTAKOEN KOPURUA: 0";
            lblTiempo.Text = $"DENBORA: {tiempo}"; //Corrección
            cronometro.Interval = 1000;
            cronometro.Tick += Cronometro_Tick;
            cronometro.Start();
            sumarSeleccionado = false;
            restarSeleccionado = false;
            seleccionarkenketa();
            selecionarGehiketa(); ;
            GenerarPregunta();
            
        }

        private void Cronometro_Tick(object sender, EventArgs e)
        {
            tiempo--;
            lblTiempo.Text = $"DENBORA: {tiempo}";
            if (tiempo <= 0)
            {
                cronometro.Stop();
                MessageBox.Show($"DENBORA BUKATU DA. ASMATUTAKOEN KOPURUA: {aciertosTotales}");
            }
        }

        private void GenerarPregunta()
        {
            labelResult.Text = "";
            int a = random.Next(numeroInicial, numeroFinal);
            int b = random.Next(numeroInicial, numeroFinal);

            string tipoOperacion = sumarSeleccionado && restarSeleccionado ? "biak" : "";

            if (tipoOperacion.ToLower() == "biak")
            {
                tipoOperacion = (random.Next(2) == 0) ? "+" : "-";
            }
            else
            {
                tipoOperacion = sumarSeleccionado ? "+" : "-";
            }

            if (tipoOperacion == "-" && a < b)
            {
                (a, b) = (b, a);
            }

            labelQuestion.Text = tipoOperacion == "+" ? $"Zenbat da {a} + {b}?" : $"Zenbat da {a} - {b}?";
            respuestaCorrecta = tipoOperacion == "+" ? a + b : a - b;

            int correcta = random.Next(1, 4);
            List<int> opciones = new List<int> { respuestaCorrecta };

            while (opciones.Count < 3)
            {
                int opcion = respuestaCorrecta + random.Next(-10, 11);
                if (!opciones.Contains(opcion))
                    opciones.Add(opcion);
            }

            opciones = opciones.OrderBy(x => random.Next()).ToList();
            btnOpcion1.Text = opciones[0].ToString();
            btnOpcion2.Text = opciones[1].ToString();
            btnOpcion3.Text = opciones[2].ToString();
        }

        private void ComprobarRespuesta(Button boton)
        {
            int respuesta = int.Parse(boton.Text);
            if (respuesta == respuestaCorrecta)
            {
                aciertos++;
                aciertosTotales++;
                labelResult.Text = "OSO ONDO!";
                boton.BackColor = Color.Green; // Cambia el color a verde para respuesta correcta
                if (aciertos == 8)
                {
                    SubirNivel();
                    aciertos = 0;
                }
                lblAciertos.Text = $"ASMATUTAKOEN KOPURUA: {aciertosTotales}";
                GenerarPregunta();

                // Restablece el color del botón después de un breve retraso
                System.Threading.Timer timer = new System.Threading.Timer((obj) =>
                {
                    boton.Invoke(new Action(() => boton.BackColor = Color.PaleTurquoise));
                }, null, 500, System.Threading.Timeout.Infinite);
            }
            else
            {
                errores++;
                labelResult.Text = "SAIATU BERRIRO!";
                boton.BackColor = Color.Red; // Cambia el color a rojo para respuesta incorrecta

                // Restablece el color del botón después de un breve retraso
                System.Threading.Timer timer = new System.Threading.Timer((obj) =>
                {
                    boton.Invoke(new Action(() => boton.BackColor = Color.PaleTurquoise));
                }, null, 500, System.Threading.Timeout.Infinite);
            }
        }

        private void SubirNivel()
        {
            numeroInicial += 20;
            numeroFinal += 100;
            MessageBox.Show("MAILA BERRIRA PASATU ZARA!");
        }

        private void btnOpcion1_Click(object sender, EventArgs e)
        {
            ComprobarRespuesta(btnOpcion1);
        }

        private void btnOpcion2_Click(object sender, EventArgs e)
        {
            ComprobarRespuesta(btnOpcion2);
        }

        private void btnOpcion3_Click(object sender, EventArgs e)
        {
            ComprobarRespuesta(btnOpcion3);
        }

        private void btnGehiketa_Click(object sender, EventArgs e)
        {
            selecionarGehiketa();
            GenerarPregunta();
        }

        private void selecionarGehiketa()
        {
            sumarSeleccionado = !sumarSeleccionado; // Invierte el estado
            btnGehiketa.FlatAppearance.BorderColor = sumarSeleccionado ? Color.White : Color.Black;
            btnGehiketa.BackColor = sumarSeleccionado ? Color.DarkGoldenrod : Color.Orange;

        }

        private void btnKenketa_Click(object sender, EventArgs e)
        {
            seleccionarkenketa();
            GenerarPregunta();
        }
        private void seleccionarkenketa()
        {
            restarSeleccionado = !restarSeleccionado; // Invierte el estado
            btnKenketa.FlatAppearance.BorderColor = restarSeleccionado ? Color.White : Color.Black;
            btnKenketa.BackColor = restarSeleccionado ? Color.DarkGoldenrod : Color.Orange;
        }





        #region "Ranking"
        private void btnGuardarPuntuacion_Click(object sender, EventArgs e)
        {
            cargarRanking();
            CalcularPuntuacionYGuardar();
            btnGuardarPuntuacion.Enabled = false;
        }
        private void btnMostrarRanking_Click(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists(rutaRanking))
                {
                    // Crear el archivo vacío con una lista vacía de rankings
                    List<Matematika_Ranking> listaVacia = new List<Matematika_Ranking>();
                    string jsonVacio = JsonSerializer.Serialize(listaVacia);
                    File.WriteAllText(rutaRanking, jsonVacio);
                }

                List<Matematika_Ranking> ranking = cargarRanking();

                if (ranking != null && ranking.Count > 0)
                {
                    FormRanking formRanking = new FormRanking(ranking);
                    formRanking.ShowDialog();
                }
                else
                {
                    MessageBox.Show("El ranking está vacío.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al mostrar el ranking: {ex.Message}");
            }

        }

        private List<Matematika_Ranking> cargarRanking()
        {
            string json = File.ReadAllText(rutaRanking);
            return JsonSerializer.Deserialize<List<Matematika_Ranking>>(json);
        }




        private void AgregarAlRanking(string nombreJugador, int puntuacion)
        {
            ranking = cargarRanking();
            ranking.Add(new Matematika_Ranking { Jugador = nombreJugador, Puntuacion = puntuacion, Fecha = DateTime.Now });
            ranking = ranking.OrderByDescending(x => x.Puntuacion).ThenBy(x => x.Fecha).Take(5).ToList();
            string json = JsonSerializer.Serialize(ranking);
            File.WriteAllText(rutaRanking, json);
        }

        private void CalcularPuntuacionYGuardar()
        {
            cronometro.Stop();
            int puntuacion = aciertosTotales - (errores * 2); // Ajusta la ponderación de los errores
            if (nombreJugador == "")
            {

                var formularioNombre = new FormNombreJugador();
                if (formularioNombre.ShowDialog() == DialogResult.OK)
                {
                    nombreJugador = formularioNombre.NombreJugador;
                }
            }
            AgregarAlRanking(nombreJugador, puntuacion);

            #endregion
        }
    }
}
